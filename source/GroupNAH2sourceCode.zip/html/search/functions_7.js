var searchData=
[
  ['othello',['Othello',['../classboard_game_1_1_othello.html#a8933180247984bd693df9967646f937d',1,'boardGame::Othello']]],
  ['othellogui',['OthelloGUI',['../class_othello_g_u_i.html#a17e905ba68b6fc159b13a75c43927cc1',1,'OthelloGUI']]],
  ['othellopiece',['OthelloPiece',['../classpiece_1_1_othello_piece.html#a64302326cc71122ee76ab15bccf3599f',1,'piece::OthelloPiece']]]
];

var searchData=
[
  ['piece',['piece',['../namespacepiece.html',1,'']]],
  ['player',['Player',['../namespace_player.html',1,'']]]
];

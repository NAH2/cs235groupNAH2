var searchData=
[
  ['playeronecolor',['playerOneColor',['../class_g_u_i.html#a8f4bf4b0a7ce30e58a3a3300ad38940f',1,'GUI']]]
];

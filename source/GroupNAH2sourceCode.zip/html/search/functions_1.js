var searchData=
[
  ['boardgame',['BoardGame',['../classboard_game_1_1_board_game.html#a7d075d392a2da7387866ad0921287659',1,'boardGame::BoardGame']]]
];

var searchData=
[
  ['m_5fboard',['m_board',['../class_g_u_i.html#a7b4c94fbc3f76b48c0c3e867f12c732a',1,'GUI']]],
  ['m_5fframe',['m_frame',['../class_g_u_i.html#ac60f08595b7f2b7c24f88c6ef418947f',1,'GUI']]],
  ['m_5fgame',['m_game',['../class_g_u_i.html#af88ae2a003445d07bfd31c64e4816bbd',1,'GUI']]],
  ['m_5fheight',['m_height',['../class_g_u_i.html#ac46fd4fb4388bc93cfba18cfe4d2e6e8',1,'GUI']]],
  ['m_5flabels',['m_labels',['../class_g_u_i.html#a4a9ab5e3941a0260ea6a643ab025390d',1,'GUI']]],
  ['m_5fpanels',['m_panels',['../class_g_u_i.html#ac34f39d4ab62656fceb5299f3b22cbfb',1,'GUI']]],
  ['m_5fpassmove',['m_passMove',['../class_g_u_i.html#a77101983b71b83b077ee468ed0278772',1,'GUI']]],
  ['m_5fpiececolor',['m_pieceColor',['../class_player_1_1_player.html#a54dd9390a2996b4c95eb84a10f542a85',1,'Player::Player']]],
  ['m_5fplayername',['m_playerName',['../class_player_1_1_player.html#ae0d0eb69723836aefbfbe50171f025f1',1,'Player::Player']]],
  ['m_5fwidth',['m_width',['../class_g_u_i.html#acb2169e1adef8d0ba78d98e7846e5c27',1,'GUI']]]
];

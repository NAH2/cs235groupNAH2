var searchData=
[
  ['boardgame',['BoardGame',['../classboard_game_1_1_board_game.html',1,'boardGame']]]
];

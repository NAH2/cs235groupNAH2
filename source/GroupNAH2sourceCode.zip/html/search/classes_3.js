var searchData=
[
  ['humanplayer',['HumanPlayer',['../class_player_1_1_human_player.html',1,'Player']]],
  ['humanplayertestjunit',['HumanPlayerTestJUnit',['../class_player_1_1_human_player_test_j_unit.html',1,'Player']]]
];

var searchData=
[
  ['boardgame',['boardGame',['../namespaceboard_game.html',1,'']]]
];

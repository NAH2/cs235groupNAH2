var searchData=
[
  ['updateplayerturnicon',['UpdatePlayerTurnIcon',['../class_g_u_i.html#a7ec9dcd95ce6976a649fb7762ef5b54a',1,'GUI']]]
];

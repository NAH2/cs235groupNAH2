var searchData=
[
  ['m_5fboard',['m_board',['../class_g_u_i.html#a7b4c94fbc3f76b48c0c3e867f12c732a',1,'GUI']]],
  ['m_5fframe',['m_frame',['../class_g_u_i.html#ac60f08595b7f2b7c24f88c6ef418947f',1,'GUI']]],
  ['m_5fgame',['m_game',['../class_g_u_i.html#af88ae2a003445d07bfd31c64e4816bbd',1,'GUI']]],
  ['m_5fheight',['m_height',['../class_g_u_i.html#ac46fd4fb4388bc93cfba18cfe4d2e6e8',1,'GUI']]],
  ['m_5flabels',['m_labels',['../class_g_u_i.html#a4a9ab5e3941a0260ea6a643ab025390d',1,'GUI']]],
  ['m_5fpanels',['m_panels',['../class_g_u_i.html#ac34f39d4ab62656fceb5299f3b22cbfb',1,'GUI']]],
  ['m_5fpassmove',['m_passMove',['../class_g_u_i.html#a77101983b71b83b077ee468ed0278772',1,'GUI']]],
  ['m_5fpiececolor',['m_pieceColor',['../class_player_1_1_player.html#a54dd9390a2996b4c95eb84a10f542a85',1,'Player::Player']]],
  ['m_5fplayername',['m_playerName',['../class_player_1_1_player.html#ae0d0eb69723836aefbfbe50171f025f1',1,'Player::Player']]],
  ['m_5fwidth',['m_width',['../class_g_u_i.html#acb2169e1adef8d0ba78d98e7846e5c27',1,'GUI']]],
  ['main',['main',['../classboard_game_1_1_connect_four.html#a26acd3c1721afaad85e9ac0eccdd7d6a',1,'boardGame.ConnectFour.main()'],['../classboard_game_1_1_othello.html#af53823007289b25d4decb09f81d123e4',1,'boardGame.Othello.main()'],['../class_game_controller.html#aa1e778994dd715bdf988d4c672616067',1,'GameController.main()'],['../classpiece_1_1_connect_four_piece.html#a1e22321071729bee0158f1bf62da3add',1,'piece.ConnectFourPiece.main()'],['../classpiece_1_1_othello_piece.html#af491cf29ed363ded0dd72068753a2b22',1,'piece.OthelloPiece.main()'],['../class_player_1_1_human_player.html#a5869608047cabb73df1820449ad94f5d',1,'Player.HumanPlayer.main()'],['../class_player_1_1_player.html#aaf5a76a9c39fbe461b5ac990b665f662',1,'Player.Player.main()'],['../class_select_game.html#a96de71fb2294726fada756ed71707082',1,'SelectGame.main()'],['../class_selection.html#a174d8974906b94f00ea16e1bb138a24c',1,'Selection.main()']]],
  ['move',['Move',['../classboard_game_1_1_board_game.html#a84830e5074327491b5a381d02bec0c91',1,'boardGame.BoardGame.Move()'],['../classboard_game_1_1_connect_four.html#aaa9bad49cf2ad762aac603554a0f5450',1,'boardGame.ConnectFour.Move()'],['../classboard_game_1_1_othello.html#a3694fe1581540beb23c16cf96f485d34',1,'boardGame.Othello.Move()']]]
];

var searchData=
[
  ['winningcondition',['WinningCondition',['../classboard_game_1_1_board_game.html#a3e7b8344008f27ca52e466125a03e005',1,'boardGame.BoardGame.WinningCondition()'],['../classboard_game_1_1_connect_four.html#a68672065aa3ab9b751c1cea748a2a6b0',1,'boardGame.ConnectFour.WinningCondition()'],['../classboard_game_1_1_othello.html#ab8a23388b6801ce006886fb59167a60b',1,'boardGame.Othello.WinningCondition()']]]
];
